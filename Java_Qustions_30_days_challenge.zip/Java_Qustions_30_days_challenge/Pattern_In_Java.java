class Pattern_in_Java {
  public static void main(String[] args) {
      int row=6;
      for (int i=0;i<row;i++) 
      {
          for (int j=0;j<=i;j++)
           {
              System.out.print("* ");// here we use only print statement it is print the *
          }
          System.out.println(" ");// here we use  println statement it is break the line 
        }
  }
}




  