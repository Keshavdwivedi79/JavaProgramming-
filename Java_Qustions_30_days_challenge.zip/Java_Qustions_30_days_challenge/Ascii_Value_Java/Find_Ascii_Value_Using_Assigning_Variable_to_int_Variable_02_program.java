package Ascii_Value_Java;
// here we use same the assigning the variable to int variable  method 
// Similarly, we can print the ASCII value of other characters (A, B, C, …., Z) and symbols (!, @, $, *, etc.).
public class Find_Ascii_Value_Using_Assigning_Variable_to_int_Variable_02_program {
    public static void main(String args[])
    {
        int ch ='@';
        int ch1='l';
        System.out.println("The Ascii value is "+ch);
        System.out.println("The Ascii value is "+ch1);
    }
}
// Note -> it is print Decimal Number it is not print hexadecimal and octal number but ascii have octal and hexadecimal number also   