package Ascii_Value_Java;

public class Print_Ascii_Value_Using_For_loop {
    
    public static void main(String args[])
    {
    //     for(int i ='A';i<='Z';i++)
    //     {
    //         System.out.println("The Ascii Value is:"+(char)i+" " +i);
    //          // here  when we print Alphabet also so we use ((char)i) value which is print alphabet A to Z in your output 

    //     }

    for(int i =0;i<=225;i++)
    {
        System.out.println("The Ascii Value is:"+(char)i+" " +i);
         // here  when we print Alphabet also so we use ((char)i) value which is print alphabet A to Z in your output 

    }
}
}
